<div class="footerdiv">
	<p>Silaris Informations Pvt ltd &copy; <?php echo date('Y');?></p>
</div>


<script src="../assets/js/popper.js"></script>
<script src="../assets/js/bootstrap.js"></script>
</body>
</html>