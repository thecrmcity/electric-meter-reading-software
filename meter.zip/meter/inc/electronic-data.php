<?php
include('header.php');
include('top-head.php');
?>
<div class="main-cont">
	
	<div class="mainbar">
		<div class="container">
			<div class="innerbar">
			</div>
		</div>
	</div>
</div>

<?php
include('footer.php');

?>